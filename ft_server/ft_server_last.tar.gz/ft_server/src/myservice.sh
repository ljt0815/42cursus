#!/bin/bash

if [ $NO_AUTOINDEX -eq 1 ]; then
	mv /tmp/autoindex /etc/nginx/sites-enabled/default
else
	mv /tmp/no_autoindex /etc/nginx/sites-enabled/default
fi

service nginx start
service php7.3-fpm start
service mysql start

tail -f /etc/issue
